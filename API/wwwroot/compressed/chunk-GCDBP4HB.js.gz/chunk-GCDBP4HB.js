var a={production:!0,apiUrl:"",clientUrl:"",googleClientId:"YOUR_GOOGLE_CLIENT_ID",saasName:"SaaS Name",saasUrl:"https://www.my-saas.com/",googleAnalyticsUrl:""};export{a};
